<!-- ********************************************************************* -->
	<!--****************** Site footer      ***********************************-->
	<!-- ********************************************************************* -->


			<?php get_sidebar('footer-first'); ?>
			<?php get_sidebar('footer-second'); ?>

			<footer class="site-footer">
				<section class="layout">
					<span class="site-credit">تمامی حقوق این سایت برای شرکت هنر چیدمان ویرا محفوظ می باشد.</span>

					<span class="site-designer">
						<?php echo __('Designed by ','viradeco');?>
						<a href="karait.com"><?php echo __('Farakaranet ','viradeco');?></a>
					</span>
				</section>
			</footer> <!-- footer -->
	
	
	

	<!-- scrolltofixed menu -->
	
	
		</div>

		<?php wp_footer(); ?>
	</body><!-- body -->
</html><!-- html -->