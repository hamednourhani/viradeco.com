<?php if ( is_active_sidebar( 'sidebar' )) : ?>
		
					<div class="sidebar-widget">
						<?php dynamic_sidebar( 'sidebar' ); ?> 	
						<!-- <aside class="widget product-widget">
							<header class="widgettitle">
								<h4>لینک های مهم</h4>
							</header>
							<main class="widgetbody">
								<ul class="products-list">
									<li><i class="fa fa-instagram"></i><span>اینستاگرام</span></li>
									<li><i class="fa fa-linkedin-square"></i><span>لینکداین</span></li>
									<li><i class="fa fa-book"></i><span>دانلود کاتالوگ</span></li>
								</ul>
							</main>
						</aside>
						<aside class="widget product-widget">
							<header class="widgettitle">
								<h4> آخرین پروژه ها</h4>
							</header>
							<main class="widgetbody">
								<ul class="products-list">
									<li><img src="images/thumb/managment/thumb1.png" alt=""><span>شرکت مسکن گستر</span></li>
									<li><img src="images/thumb/managment/thumb2.png" alt=""><span>سازمان مدیریت اکتشاف</span></li>
									<li><img src="images/thumb/managment/thumb3.png" alt=""><span>سازمان انتقال خون</span></li>
									<li><img src="images/thumb/managment/thumb4.png" alt=""><span>شرکت سها</span></li>
									<li><img src="images/thumb/managment/thumb5.png" alt=""><span>سازمان بیمه مرکزی</span></li>
								</ul>
							</main>
						</aside>
						<aside class="widget product-widget">
							<header class="widgettitle">
								<h4>دسته بندی محصولات</h4>
							</header>
							<main class="widgetbody">
								<ul class="products-list">
									<li><img src="images/thumb/conf/thumb1.png" alt=""><span>میزهای کنفرانس</span></li>
									<li><img src="images/thumb/counter/thumb1.png" alt=""><span>کانتر</span></li>
									<li><img src="images/thumb/empolyee/thumb1.png" alt=""><span>میزهای کارمندی</span></li>
									<li><img src="images/thumb/managment/thumb1.png" alt=""><span>میزهای مدیریتی</span></li>
									<li><img src="images/thumb/wall/thumb1.png" alt=""><span>پوشش های دیواری</span></li>
								</ul>
								
							</main>
						</aside> -->
					</div>
				
				

				
	 
 <?php endif; ?>